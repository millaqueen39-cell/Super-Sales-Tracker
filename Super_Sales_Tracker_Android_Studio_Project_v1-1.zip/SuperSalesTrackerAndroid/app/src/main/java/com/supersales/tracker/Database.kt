package com.supersales.tracker

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class Database(context: Context) : SQLiteOpenHelper(context, "super_sales.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE shops(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT,area TEXT,note TEXT)")
        db.execSQL("CREATE TABLE visits(id INTEGER PRIMARY KEY AUTOINCREMENT,shopId INTEGER,date TEXT,result TEXT,stock TEXT,need TEXT,note TEXT)")
        db.execSQL("CREATE TABLE orders(id INTEGER PRIMARY KEY AUTOINCREMENT,shopId INTEGER,date TEXT,product TEXT,qty REAL,unitPrice REAL,total REAL,paid REAL,note TEXT)")
        db.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,shopId INTEGER,date TEXT,amount REAL,method TEXT,reference TEXT)")
        db.execSQL("CREATE TABLE routes(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,name TEXT,km REAL,mode TEXT)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun add(table:String, values:ContentValues) = writableDatabase.insert(table,null,values)
    fun rows(sql:String): List<Map<String,String>> {
        val out= mutableListOf<Map<String,String>>()
        readableDatabase.rawQuery(sql,null).use { c ->
            while(c.moveToNext()) {
                val row= mutableMapOf<String,String>()
                for(i in 0 until c.columnCount) row[c.getColumnName(i)] = c.getString(i) ?: ""
                out.add(row)
            }
        }
        return out
    }
    fun scalar(sql:String): Double = readableDatabase.rawQuery(sql,null).use { c -> if(c.moveToFirst()) c.getDouble(0) else 0.0 }
    fun backupJson(): String {
        val tables=listOf("shops","visits","orders","payments","routes")
        val root=org.json.JSONObject()
        for (table in tables) {
            val array=org.json.JSONArray()
            for (row in rows("SELECT * FROM $table")) {
                val obj=org.json.JSONObject()
                for ((key,value) in row) obj.put(key,value)
                array.put(obj)
            }
            root.put(table,array)
        }
        return root.toString(2)
    }
}

package com.supersales.tracker

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.location.Location
import android.os.Build
import android.os.IBinder
import com.google.android.gms.location.*
import android.content.ContentValues
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class RouteTrackingService : Service() {
    private lateinit var client: FusedLocationProviderClient
    private var previous: Location? = null
    private var km = 0.0
    private var routeName = "Field Route"
    private val callback = object: LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            for (loc in result.locations) {
                previous?.let { old ->
                    val d=old.distanceTo(loc)/1000.0
                    if(loc.accuracy < 60 && d < 2.0) km += d
                }
                previous=loc
                getSharedPreferences("route", MODE_PRIVATE).edit().putFloat("km",km.toFloat()).apply()
            }
        }
    }
    override fun onCreate() {
        super.onCreate()
        client=LocationServices.getFusedLocationProviderClient(this)
        if(Build.VERSION.SDK_INT>=26) {
            val nm=getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("route","Route tracking",NotificationManager.IMPORTANCE_LOW))
        }
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        routeName=intent?.getStringExtra("routeName") ?: routeName
        val notification: Notification = if(Build.VERSION.SDK_INT>=26)
            Notification.Builder(this,"route").setContentTitle("Super Sales Tracker").setContentText("GPS route tracking: $routeName").setSmallIcon(android.R.drawable.ic_menu_mylocation).build()
        else Notification.Builder(this).setContentTitle("Super Sales Tracker").setContentText("GPS tracking").setSmallIcon(android.R.drawable.ic_menu_mylocation).build()
        startForeground(7,notification)
        val request=LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY,5000).setMinUpdateDistanceMeters(10f).build()
        try { client.requestLocationUpdates(request,callback,mainLooper) } catch (_: SecurityException) {}
        return START_STICKY
    }
    override fun onDestroy() {
        client.removeLocationUpdates(callback)
        val values=ContentValues().apply {
            put("date",SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date()))
            put("name",routeName); put("km",km); put("mode","GPS")
        }
        Database(this).add("routes",values)
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}

package com.supersales.tracker

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Navy=Color(0xFF123B66)
class MainActivity : ComponentActivity() {
    private lateinit var db: Database
    private val permissionLauncher=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db=Database(this)
        val permissions= mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION)
        if(Build.VERSION.SDK_INT>=33) permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        permissionLauncher.launch(permissions.toTypedArray())
        setContent { MaterialTheme(colorScheme=lightColorScheme(primary=Navy)) { SalesApp(db,
            onStartRoute={ name ->
                if(ContextCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED) {
                    ContextCompat.startForegroundService(this,Intent(this,RouteTrackingService::class.java).putExtra("routeName",name))
                } else Toast.makeText(this,"আগে Location permission দিন",Toast.LENGTH_LONG).show()
            },
            onStopRoute={ stopService(Intent(this,RouteTrackingService::class.java)) },
            onBackup={ shareBackup() }) } }
    }
    private fun shareBackup() {
        val text=db.backupJson()
        val i=Intent(Intent.ACTION_SEND).setType("application/json").putExtra(Intent.EXTRA_TEXT,text)
        startActivity(Intent.createChooser(i,"Backup share/save"))
    }
}
@Composable
fun SalesApp(db:Database,onStartRoute:(String)->Unit,onStopRoute:()->Unit,onBackup:()->Unit) {
    var tab by remember { mutableStateOf("Home") }
    var refresh by remember { mutableIntStateOf(0) }
    var shopName by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var area by remember { mutableStateOf("") }
    var selectedShop by remember { mutableStateOf("1") }
    var routeName by remember { mutableStateOf("") }; var km by remember { mutableStateOf("") }
    var product by remember { mutableStateOf("Super Star LED Bulb 9W") }; var qty by remember { mutableStateOf("1") }; var price by remember { mutableStateOf("") }; var paid by remember { mutableStateOf("0") }
    var stock by remember { mutableStateOf("") }; var need by remember { mutableStateOf("") }; var visitNote by remember { mutableStateOf("") }
    var payment by remember { mutableStateOf("") }
    val shops= remember(refresh) { db.rows("SELECT * FROM shops ORDER BY name") }
    val today=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
    val sales=remember(refresh){db.scalar("SELECT COALESCE(SUM(total),0) FROM orders WHERE date='$today'")}
    val collected=remember(refresh){db.scalar("SELECT COALESCE(SUM(amount),0) FROM payments WHERE date='$today'")+db.scalar("SELECT COALESCE(SUM(paid),0) FROM orders WHERE date='$today'")}
    val visits=remember(refresh){db.scalar("SELECT COUNT(*) FROM visits WHERE date='$today'").toInt()}
    val due=remember(refresh){db.scalar("SELECT COALESCE(SUM(total-paid),0) FROM orders")-db.scalar("SELECT COALESCE(SUM(amount),0) FROM payments")}
    Scaffold(topBar={ TopAppBarSimple() }, bottomBar={
        NavigationBar { listOf("Home","Route","Shops","Visit","Order","Payment","Report").forEach { item ->
            NavigationBarItem(selected=tab==item,onClick={tab=item},icon={},label={Text(item)})
        } }
    }) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(14.dp)) {
            when(tab) {
                "Home" -> {
                    Text("আজকের সারসংক্ষেপ",style=MaterialTheme.typography.titleLarge)
                    Row { Metric("ভিজিট",visits.toString(),Modifier.weight(1f)); Metric("বিক্রয়","৳${sales.toInt()}",Modifier.weight(1f)) }
                    Row { Metric("কালেকশন","৳${collected.toInt()}",Modifier.weight(1f)); Metric("মোট বকেয়া","৳${due.toInt()}",Modifier.weight(1f)) }
                    Text("Super Star Bulb • Field Sales Assistant",color=Navy)
                    Button(onClick={tab="Visit"},modifier=Modifier.fillMaxWidth()) { Text("নতুন দোকান ভিজিট") }
                }
                "Route" -> {
                    Text("রুট ও GPS KM",style=MaterialTheme.typography.titleLarge)
                    OutlinedTextField(routeName,{routeName=it},label={Text("রুটের নাম")},modifier=Modifier.fillMaxWidth())
                    Button(onClick={onStartRoute(routeName.ifBlank{"Field Route"})},modifier=Modifier.fillMaxWidth()){Text("GPS Tracking শুরু")}
                    OutlinedTextField(km,{km=it},label={Text("ম্যানুয়াল দূরত্ব (KM)")},modifier=Modifier.fillMaxWidth())
                    Button(onClick={ val v=km.toDoubleOrNull(); if(v!=null&&v>0){db.add("routes",ContentValues().apply{put("date",today);put("name",routeName);put("km",v);put("mode","Manual")});km="";refresh++} },modifier=Modifier.fillMaxWidth()){Text("ম্যানুয়াল KM সংরক্ষণ")}
                    OutlinedButton(onClick=onStopRoute,modifier=Modifier.fillMaxWidth()){Text("GPS Tracking বন্ধ / রুট শেষ")}
                    Text("সাম্প্রতিক রুট",style=MaterialTheme.typography.titleMedium)
                    db.rows("SELECT * FROM routes ORDER BY id DESC LIMIT 20").forEach { Text("${it["date"]} • ${it["name"]} • ${it["km"]} km (${it["mode"]})") }
                }
                "Shops" -> {
                    Text("দোকান ম্যানেজমেন্ট",style=MaterialTheme.typography.titleLarge)
                    OutlinedTextField(shopName,{shopName=it},label={Text("দোকানের নাম *")},modifier=Modifier.fillMaxWidth())
                    OutlinedTextField(phone,{phone=it},label={Text("ফোন নম্বর")},modifier=Modifier.fillMaxWidth())
                    OutlinedTextField(area,{area=it},label={Text("এলাকা / বাজার")},modifier=Modifier.fillMaxWidth())
                    Button(onClick={if(shopName.isNotBlank()){db.add("shops",ContentValues().apply{put("name",shopName);put("phone",phone);put("area",area)});shopName="";phone="";area="";refresh++}},modifier=Modifier.fillMaxWidth()){Text("দোকান সংরক্ষণ")}
                    LazyColumn { items(shops){s-> Text("${s["name"]} • ${s["phone"]} • ${s["area"]}",Modifier.padding(8.dp)); Divider() } }
                }
                "Visit" -> {
                    Text("দোকান ভিজিট",style=MaterialTheme.typography.titleLarge)
                    ShopPicker(shops,selectedShop){selectedShop=it}
                    OutlinedTextField(stock,{stock=it},label={Text("দোকানে কী স্টক আছে?")},modifier=Modifier.fillMaxWidth())
                    OutlinedTextField(need,{need=it},label={Text("কী মাল লাগবে?")},modifier=Modifier.fillMaxWidth())
                    OutlinedTextField(visitNote,{visitNote=it},label={Text("ভিজিট নোট")},modifier=Modifier.fillMaxWidth())
                    Button(onClick={db.add("visits",ContentValues().apply{put("shopId",selectedShop.toLongOrNull()?:0);put("date",today);put("result","Visited");put("stock",stock);put("need",need);put("note",visitNote)});stock="";need="";visitNote="";refresh++},modifier=Modifier.fillMaxWidth()){Text("ভিজিট সংরক্ষণ")}
                    Text("আজকের ভিজিট: $visits")
                }
                "Order" -> {
                    Text("অর্ডার ও বিক্রয়",style=MaterialTheme.typography.titleLarge)
                    ShopPicker(shops,selectedShop){selectedShop=it}
                    OutlinedTextField(product,{product=it},label={Text("পণ্যের নাম / Watt")},modifier=Modifier.fillMaxWidth())
                    OutlinedTextField(qty,{qty=it},label={Text("পরিমাণ (পিস)")},modifier=Modifier.fillMaxWidth())
                    OutlinedTextField(price,{price=it},label={Text("প্রতি পিস মূল্য (৳)")},modifier=Modifier.fillMaxWidth())
                    OutlinedTextField(paid,{paid=it},label={Text("এখন পরিশোধ (৳)")},modifier=Modifier.fillMaxWidth())
                    Button(onClick={val q=qty.toDoubleOrNull();val p=price.toDoubleOrNull();val pay=paid.toDoubleOrNull()?:0.0;if(q!=null&&p!=null&&q>0&&p>=0&&pay>=0&&pay<=q*p){db.add("orders",ContentValues().apply{put("shopId",selectedShop.toLongOrNull()?:0);put("date",today);put("product",product);put("qty",q);put("unitPrice",p);put("total",q*p);put("paid",pay)});refresh++}},modifier=Modifier.fillMaxWidth()){Text("অর্ডার সংরক্ষণ")}
                    Text("সর্বশেষ অর্ডার"); db.rows("SELECT * FROM orders ORDER BY id DESC LIMIT 10").forEach{Text("${it["date"]} • ${it["product"]} × ${it["qty"]} • ৳${it["total"]} • জমা ৳${it["paid"]}")}
                }
                "Payment" -> {
                    Text("কালেকশন",style=MaterialTheme.typography.titleLarge)
                    ShopPicker(shops,selectedShop){selectedShop=it}
                    OutlinedTextField(payment,{payment=it},label={Text("আদায়কৃত টাকা (৳)")},modifier=Modifier.fillMaxWidth())
                    Button(onClick={val a=payment.toDoubleOrNull();if(a!=null&&a>0){db.add("payments",ContentValues().apply{put("shopId",selectedShop.toLongOrNull()?:0);put("date",today);put("amount",a);put("method","Cash")});payment="";refresh++}},modifier=Modifier.fillMaxWidth()){Text("কালেকশন সংরক্ষণ")}
                    Text("দোকানভিত্তিক বকেয়া",style=MaterialTheme.typography.titleMedium)
                    db.rows("SELECT s.name, COALESCE((SELECT SUM(total-paid) FROM orders o WHERE o.shopId=s.id),0)-COALESCE((SELECT SUM(amount) FROM payments p WHERE p.shopId=s.id),0) AS due FROM shops s").forEach{Text("${it["name"]} • ৳${it["due"]}")}
                }
                "Report" -> {
                    Text("রিপোর্ট ও ব্যাকআপ",style=MaterialTheme.typography.titleLarge)
                    Text("মোট অর্ডার: ৳${db.scalar("SELECT COALESCE(SUM(total),0) FROM orders").toInt()}")
                    Text("মোট কালেকশন: ৳${db.scalar("SELECT COALESCE(SUM(amount),0) FROM payments").toInt()}")
                    Text("মোট ভিজিট: ${db.scalar("SELECT COUNT(*) FROM visits").toInt()}")
                    Text("মোট রাইড: ${db.scalar("SELECT COALESCE(SUM(km),0) FROM routes")} km")
                    Button(onClick=onBackup,modifier=Modifier.fillMaxWidth()){Text("JSON ব্যাকআপ শেয়ার / সেভ")}
                }
            }
        }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable fun TopAppBarSimple(){TopAppBar(title={Column{Text("Super Sales Tracker");Text("Super Star Bulb • Field Sales",style=MaterialTheme.typography.labelSmall)}})}
@Composable fun Metric(label:String,value:String,modifier:Modifier=Modifier){Card(modifier.padding(4.dp)){Column(Modifier.padding(12.dp)){Text(label);Text(value,style=MaterialTheme.typography.headlineSmall,color=Navy)}}}
@Composable fun ShopPicker(shops:List<Map<String,String>>,selected:String,onSelect:(String)->Unit){
    var expanded by remember{mutableStateOf(false)}
    ExposedDropdownMenuBox(expanded=expanded,onExpandedChange={expanded=!expanded}) {
        OutlinedTextField(value=shops.firstOrNull{it["id"]==selected}?.get("name")?:if(shops.isEmpty())"আগে দোকান যোগ করুন" else "দোকান নির্বাচন করুন",
            onValueChange={},readOnly=true,label={Text("দোকান")},modifier=Modifier.menuAnchor().fillMaxWidth())
        ExposedDropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) {
            shops.forEach{s->DropdownMenuItem(text={Text(s["name"]?: "")},onClick={onSelect(s["id"]?: "1");expanded=false})}
        }
    }
}

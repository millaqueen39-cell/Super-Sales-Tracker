# Super Sales Tracker — Android Studio Project (v1.0)

এটি Android Studio-তে খোলার মতো Native Android source project। এখনো APK নয়; Android Studio দিয়ে Build করতে হবে।

## APK বানানোর ধাপ
1. কম্পিউটারে Android Studio ইনস্টল করুন।
2. ZIP Extract করুন।
3. Android Studio → Open → `SuperSalesTrackerAndroid` ফোল্ডার নির্বাচন করুন।
4. Gradle sync শেষ হতে দিন (ইন্টারনেট লাগবে; dependency প্রথমবার ডাউনলোড হবে)।
5. Build → Build Bundle(s) / APK(s) → Build APK(s) নির্বাচন করুন।
6. `app/build/outputs/apk/debug/app-debug.apk` ফাইলটি ফোনে পাঠিয়ে ইনস্টল করুন।
7. ফোনে Install unknown apps অনুমতি চাইলে Chrome/File Manager-কে অনুমতি দিন।

## বর্তমান সংস্করণের ফিচার
- SQLite-এ অফলাইন দোকান, ভিজিট, অর্ডার, কালেকশন ও রুট সংরক্ষণ।
- দোকানের নাম, ফোন, এলাকা।
- দোকানভিত্তিক স্টক/চাহিদা/ভিজিট নোট।
- পণ্য, পরিমাণ, ইউনিট মূল্য, অর্ডার, তাৎক্ষণিক পেমেন্ট।
- অতিরিক্ত কালেকশন ও বকেয়া হিসাব।
- GPS foreground service দিয়ে রুটের আনুমানিক দূরত্ব; ম্যানুয়াল KM।
- রিপোর্ট ও JSON backup share।

## সীমাবদ্ধতা / সতর্কতা
- GPS চালাতে Location permission দিন। Android 13+ এ Notification permission-ও প্রয়োজন।
- Android-এর ব্যাটারি অপ্টিমাইজেশন কিছু ফোনে ব্যাকগ্রাউন্ড GPS বন্ধ করতে পারে; নির্ভরযোগ্য ব্যবহারের আগে বাস্তব ফোনে পরীক্ষা করুন।
- ব্যাকআপ বাটন JSON-কে Share sheet-এ দেয়; সেখান থেকে Drive/Files/নিজের কাছে সেভ করুন।
- এই starter project-এ অর্ডার এডিট/ডিলিট, ব্যাকআপ রিস্টোর UI, পণ্যের master catalogue, date-range report, map route drawing এবং production-grade validation এখনো নেই।
- APK এখানে compile করা হয়নি; Build-এর আগে Android Studio/Gradle-এ sync ও build test আবশ্যক।
